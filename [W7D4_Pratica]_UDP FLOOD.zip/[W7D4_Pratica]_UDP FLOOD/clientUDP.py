# Oltre al modulo socket, importiamo anche il modulo random,
# che ci sarà utile per la generazione di caratteri casuali per l'invio dei pacchetti
import socket
import random

# Specifichiamo la variabile "data" per generare una stringa casuale di caratteri da 1024 byte
data = random._urandom(1024)

# A questo punto chiediamo all'utente una serie di input, tra cui quanti pacchetti inviare,
# a quale ip e a quale porta. Noteremo che le risposte verranno convertite in int,
# fatta eccezione per l'ip che viene letta come una stringa.
packets = int(input('Inserisci il numero di pacchetti da inviare: '))
target_ip = input('Inserisci IP target: ')
target_port = int(input('Inserisci porta target: '))

# Definiamo con che tipo di socket stiamo interagendo, in questo caso sempre IpV4 - UDP
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Specifichiamo una variabile "sent" inizialmente uguale a zero, seguita da un ciclo while
# che aggiunge un +1 di valore a sent ogni volta che invia un pacchetto.
# Il ciclo while non si interrompe finché il valore di sent non è uguale a packets,
# ovvero uguale al numero di pacchetti che voleva mandare l'utente.
sent = 0
while sent < packets:
 sock.sendto(data, (target_ip, target_port))
 sent += 1
 
# Alla fine stampiamo a schermo quanti pacchetti sono stati inviati.
# La funzione "f" ci permette di rendere la stringa da stampare dinamica, cioè
# capace di sostituire il contenuto delle variabili messe tra parentesi graffe
# con il valore della variabile stessa.
print (f'{sent} pacchetti inviati.')
