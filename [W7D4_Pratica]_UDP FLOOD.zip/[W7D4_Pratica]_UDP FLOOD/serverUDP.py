# Primo passo: importare il modulo socket, utile a creare socket di rete
# per endpoint server - client. Questo è il lato server.
import socket

# L'IP per questo esercizio sarà quello della macchina Kali da noi usata.
# Viene letto dal programma come una stringa, per cui andr tra apici, 
# a differenza della porta su cui vogliamo far stare in ascolto il socket.
# La porta è scelta casualmente tra le non conosciute.
ip = '192.168.50.100'
port = 9898

# Andiamo a specificare quale tipo di socket stiamo creando.
# AF_INET indica che stiamo applicando un protocollo IpV4.
# SOCK_DGRAM che vogliamo utilizzare comunicazione UDP.
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Effettuiamo il binding su ip e porta scelti e stampiamo a schermo
# per avere feddback dell'operazione.
sock.bind((ip,port))
print ('In ascolto sulla porta 9898')

# Creaiamo un ciclo while che ametta la ricezione di dati e che stampi
# a schermo quello che ci invierà il client.
# Ovviamente questo ciclo viene creato sapendo già cosa faremo lato client.
while True:
 data, address = socket.recvfrom(1024)
 print (f'From {address}: {data}')
